# interp.py
#
# In order to write a compiler for a programming language, it helps to
# have some kind of specification of how programs written in the
# programming language are actually supposed to work. A language is
# more than just "syntax" or a data model.  There has to be some kind
# of operational semantics that describe what happens when a program
# runs.
#
# One way to specify the operational semantics is to write a so-called
# "definitional interpreter" that directly executes the data
# model. This might seem like cheating--after all, our final goal is
# not to write an interpreter, but a compiler. However, if you can't
# write an interpreter, chances are you can't write a compiler either.
# So, the purpose of doing this is to pin down fine details as well as
# our overall understanding of what needs to happen when programs run.
#
# We'll write our interpreter in Python.  The idea is relatively 
# straightforward.  For each class in the model.py file, you're
# going to write a function similar to this:
#
#    def interpret_node_name(node, env):
#        # Execute "node" in the environment "env"
#        ...
#        return result
#   
# The input to the function will be an object from model.py (node)
# along with an object respresenting the execution environment (env).
# The function will then execute the node in the environment and return
# a result.  It might also modify the environment (for example,
# when executing assignment statements, variable definitions, etc.). 
#
# For the purposes of this projrect, assume that all programs provided
# as input are "sound"--meaning that there are no programming errors
# in the input.  Our purpose is not to create a "production grade"
# interpreter.  We're just trying to understand how things actually
# work when a program runs. 
#
# For testing, try running your interpreter on the models you
# created in the example_models.py file.
#

from .model import *
from collections import ChainMap
from functools import singledispatch

# Top level function that interprets an entire program. It creates the
# initial environment that's used for storing variables.

def interpret_program(model):
    # Make the initial environment (a dict)
    env = ChainMap()
    interpret(model, env)
    
    # Main hack.  Run main if defined. 
    if 'main' in env:
        interpret(FunctionApplication("main", []), env)

@singledispatch
def interpret(node, env):
    raise RuntimeError(f"Can't interpret {node}")

rule = interpret.register

@rule(list)
def interpret_list(nodes, env):
    value = None
    for node in nodes:
        value = interpret(node, env)
    return value

@rule(Integer)
@rule(Float)
@rule(Char)
@rule(Bool)
@rule(Unit)
def interpret_literal(node, env):
    return node.value
    
@rule(BinOp)
def interpret_binop(node, env):
    if node.op == '&&' or node.op == '||':
        leftval = interpret(node.left, env)
        if leftval and node.op == '||':
            return True
        if not leftval and node.op == '&&':
            return False
    else:
        leftval = interpret(node.left, env)

    rightval = interpret(node.right, env)
    assert type(leftval) == type(rightval)

    if node.op == '+':
        return leftval + rightval
    elif node.op == '-':
        return leftval - rightval
    elif node.op == '*':
        return leftval * rightval
    elif node.op == '/':
        if isinstance(leftval, int):
            return leftval // rightval
        else:
            return leftval / rightval
    elif node.op == '<':
        return leftval < rightval
    elif node.op == '>':
        return leftval > rightval
    elif node.op == '<=':
        return leftval <= rightval
    elif node.op == '>=':
        return leftval >= rightval
    elif node.op == '==':
        return leftval == rightval
    elif node.op == '!=':
        return leftval != rightval
    elif node.op == '&&':
        return leftval and rightval
    elif node.op == '||':
        return leftval or rightval
    else:
        raise RuntimeError(f"Bad operator {node.op}")

@rule(UnaryOp)
def interpret_unaryop(node, env):
    operand_value = interpret(node.operand, env)
    if node.op == '-':
        return -operand_value
    elif node.op == '+':
        return operand_value
    elif node.op == '!':
        return not operand_value
    else:
        raise RuntimeError(f"Bad operator {node.op}")

@rule(Compound)
def interpret_compound(node, env):
    return interpret(node.statements, env.new_child())

@rule(PrintStatement)
def interpret_print_statement(node, env):
    value = interpret(node.expression, env)
    if isinstance(value, str):
        print(value, end='')
    elif isinstance(value, bool):
        print(str(value).lower())
    else:
        print(value)
    return ()

@rule(ConstDefinition)
def interpret_const_definition(node, env):
    value = interpret(node.expression, env)
    env[node.name] = value
    return ()

default_values = {
    'int': 0,
    'float': 0.0,
    'char': '\x00',
    'bool': False,
    'unit': ()
}

@rule(VarDefinition)
def interpret_var_definition(node, env):
    if node.expression:
        value = interpret(node.expression, env)
    else:
        # What is default value?
        value = default_values[node.dtype]

    env[node.name] = value

@rule(AssignmentStatement)
def interpret_assignment_statement(node, env):
    value = interpret(node.expression, env)
    _, set = interpret(node.location, env)
    set(value)

@rule(LoadLocation)
def interpret_load_location(node, env):
    get, _ = interpret(node.location, env)
    return get()

@rule(IfStatement)
def interpret_if_statement(node, env):
    test = interpret(node.test, env)
    if test:
        return interpret(node.consequence, env.new_child())
    else:
        return interpret(node.alternative, env.new_child())

@rule(IfLetStatement)
def interpret_iflet_statement(node, env):
    value = interpret(node.value, env)
    newenv = env.new_child()
    if interpret(node.pattern, newenv)(value):
        return interpret(node.consequence, newenv)
    else:
        return interpret(node.alternative, env.new_child)


class BreakException(Exception):
    pass

class ContinueException(Exception):
    pass

@rule(WhileStatement)
def interpret_while_statement(node, env):
    while True:
        test = interpret(node.test, env)
        if not test:
            break    # DONE!
        try:
            interpret(node.body, env.new_child())
        except BreakException:
            break
        except ContinueException:
            pass   # Go back to loop top

@rule(WhileLetStatement)
def interpret_whilelet_statement(node, env):
    while True:
        value = interpret(node.value, env)
        newenv = env.new_child()
        if not interpret(node.pattern, newenv)(value):
            break
        try:
            interpret(node.body, newenv)
        except BreakException:
            break
        except ContinueException:
            pass   # Go back to loop top

@rule(BreakStatement)
def interpret_break_statement(node, env):
    raise BreakException()

@rule(ContinueStatement)
def interpret_continue_statement(node, env):
    raise ContinueException()

@rule(FunctionDefinition)
def interpret_function_definition(node, env):
    # Create a function that executes evaluated arguments
    def apply(args, newenv):
        for parm, arg in zip(node.parameters, args):
            newenv[parm.name] = arg
            
        try:
            return interpret(node.body, newenv)
        except ReturnException as e:
            return e.value
        
    env[node.name] = (apply, env)
    return ()

@rule(FunctionApplication)
def interpret_function_application(node, env):
    # 1. Evaluate each of the function arguments
    args = [ interpret(arg, env) for arg in node.arguments ]

    # 2. Look up the function and definition environment
    func, defn_env = env[node.name]

    # Create a new environment
    newenv = defn_env.new_child()
    return func(args, newenv)

class ReturnException(Exception):
    def __init__(self, value):
        self.value = value

@rule(ReturnStatement)
def interpret_return_statement(node, env):
    expr = interpret(node.expression, env)
    raise ReturnException(expr)

@rule(StructDefinition)
def interpret_struct_definition(node, env):
    def apply(args, newenv):
        obj = { }
        for field, val in zip(node.fields, args):
            obj[field.name] = val
        return obj
    env[node.name] = (apply, env)
    return ()

@rule(EnumDefinition)
def interpret_enum_definition(node, env):
    env[node.name] = node
    return ()

@rule(EnumValue)
def interpret_enum_value(node, env):
    if node.expression:
        val = interpret(node.expression, env)
    else:
        val = None
    return (node.choice_name, val)

@rule(Match)
def interpret_match(node, env):
    val = interpret(node.expression, env)
    for clause in node.clauses:
        newenv = env.new_child()
        if interpret(clause.pattern, newenv)(val):
            return interpret(clause.expression, newenv)
    raise RuntimeError(f"Unmatched match case {val}")

@rule(NamedLocation)
def interpret_named_location(node, env):
    # Idea: return a pair of functions that get/set the value. Let the
    # caller decide what to do with them
    for m in env.maps:
        if node.name in m:
            break
    else:
        raise KeyError(f'{node.name} not defined')

    def getter():
        return m[node.name]

    def setter(value):
        m[node.name] = value

    return (getter, setter)

@rule(DotLocation)
def interpret_dot_location(node, env):
    obj = interpret(node.expression, env)
    def getter():
        return obj[node.name]
    def setter(value):
        obj[node.name] = value
    return (getter, setter)

@rule(NamePattern)
def interpret_name_pattern(pattern, env):
    def match(value):
        return pattern.name == value[0]
    return match

@rule(NameValuePattern)
def interpret_namevalue_pattern(pattern, env):
    def match(value):
        if pattern.name == value[0]:
            env[pattern.varname] = value[1]
            return True
        else:
            return False
    return match

# Add a main program to interp.py
# Make it so you can interpret programs given on command line
#
# python3 -m wabbit.interp filename
#
# Try it on programs in tests/Script.

from .parse import parse_source
from .typecheck import check_program

def main(filename):
    with open(filename) as file:
        text = file.read()
    model = parse_source(text)
    # Type-checking is "go" vs "no go"
    if not check_program(model):
        return     # Something is wrong
    interpret_program(model)

if __name__ == '__main__':
    import sys
    main(sys.argv[1])

                             
                             

        
        
        
