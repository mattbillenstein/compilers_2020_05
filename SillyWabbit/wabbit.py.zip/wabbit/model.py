# model.py
#
# This file defines the data model for Wabbit programs.  The data
# model is a data structure that represents the contents of a program
# as objects, not text.  Sometimes this structure is known as an
# "abstract syntax tree" or AST.  However, the model is not
# necessarily directly tied to the actual syntax of the language.  So,
# we'll prefer to think of it as a more generic data model instead.
#
# To do this, you need to identify the different "elements" that make
# up a program and encode them into classes.  To do this, it may be
# useful to slightly "underthink" the problem. To illustrate, suppose
# you wanted to encode the idea of "assigning a value."  Assignment
# involves a location (the left hand side) and a value like this:
#
#         location = expression;
#
# To represent this idea, make a class with just those parts:
#
#     class Assignment:
#         def __init__(self, location, expression):
#             self.location = location
#             self.expression = expression
#
# What are "location" and "expression"?  Does it matter? Maybe
# not. All you know is that an assignment operator definitely requires
# both of those parts.  DON'T OVERTHINK IT.  Further details will be
# filled in as the project evolves.
# 
# Work on this file in conjunction with the top-level
# "example_models.py" file.  Go look at that file and see what program
# samples are provided.  Then, figure out what those programs look like 
# in terms of data structures.
#
# There is no "right" solution to this part of the project other than
# the fact that a program has to be represented as some kind of data
# structure that's not "text."   You could use classes. You could use 
# tuples. You could make a bunch of nested dictionaries like JSON. 
# The key point: it must be a data structure.
#
# Starting out, I'd advise against making this file too fancy. Just
# use basic data structures. You can add usability enhancements later.
# -----------------------------------------------------------------------------

# The following classes are used for the expression example in example_models.py.
# Feel free to modify as appropriate.  You don't even have to use classes
# if you want to go in a different direction with it.

# Abstract Base Class (not created directly).
# Used mainly as an organizational tool.  Also as a code correctness device.

class Node:
    # This bit of code tracks all of the model subclasses that are created.
    # It's used to help validate the ModelVisitor class that is defined later.
    _registered = { }
    @classmethod
    def __init_subclass__(cls):
        # Only register concrete classes that have a constructor
        if '__init__' in cls.__dict__:
            Node._registered[cls.__name__] = cls

class Statement(Node):
    pass

# An expression reprents a "value".  Something that can be computed. Like a number.
# Can also appear as a statement

class Expression(Statement):   
    pass

# A definition represents the definition of a named thing. For example: "var x int"
class Definition(Statement):
    pass

# A location represents a place where values are loaded or stored.  Locations can
# appear both on the left and right hand sides of assignment. For example:
#
#      location = 10 + location;
#
# A location is more an internal entity used by other node types.  For example,
# in assignment or in a load expression.

class Location(Node):
    pass

class Integer(Expression):
    '''
    Example: 42
    '''
    def __init__(self, value, *, lineno=None):
        assert isinstance(value, int)
        self.value = value
        self.lineno = lineno

    def __repr__(self):
        return f'Integer({self.value})'

class Float(Expression):
    '''
    Example: 2.5
    '''
    def __init__(self, value, *, lineno=None):
        assert isinstance(value, float)
        self.value = value
        self.lineno = lineno
        
    def __repr__(self):
        return f'Float({self.value})'

class Char(Expression):
    '''
    Example:  'x'
    '''
    def __init__(self, value, *, lineno=None):
        assert isinstance(value, str)
        self.value = eval(value)    # Convert from 'x' to -> x
        self.lineno = lineno

    def __repr__(self):
        return f'Char({self.value!r})'

class Bool(Expression):
    '''
    Example: true, false
    '''
    def __init__(self, value, *, lineno=None):
        assert isinstance(value, bool)
        self.value = value
        self.lineno = lineno

    def __repr__(self):
        return f'Bool({self.value})'

class Unit(Expression):
    '''
    Example: ()
    '''
    def __init__(self, *, lineno=None):
        self.value = ()
        self.lineno = lineno

    def __repr__(self):
        return f'Unit()'

class BinOp(Expression):
    '''
    left + right
    left - right
    '''
    def __init__(self, op, left, right, *, lineno=None):
        # Sanity check.
        assert isinstance(op, str)            # '+'
        assert isinstance(left, Expression)
        assert isinstance(right, Expression)
        self.op = op
        self.left = left
        self.right = right
        self.lineno = lineno

    def __repr__(self):
        return f'BinOp({self.op}, {self.left}, {self.right})'

class Compound(Expression):
    def __init__(self, statements, *, lineno=None):
        self.statements = statements
        self.lineno = lineno

    def __repr__(self):
        return f'Compound({self.statements})'

class UnaryOp(Expression): 
    '''
    -operand
    +operand
    '''
    def __init__(self, op, operand, *, lineno=None):
        assert isinstance(op, str)
        assert isinstance(operand, Expression)
        self.op = op
        self.operand = operand
        self.lineno = lineno

    def __repr__(self):
        return f'UnaryOp({self.op}, {self.operand})'

class LoadLocation(Expression):
    def __init__(self, location, *, lineno=None):
        assert isinstance(location, Location)
        self.location = location
        self.lineno = lineno

    def __repr__(self):
        return f'LoadLocation({self.location})'

class PrintStatement(Statement):
    '''
    print expression ;
    '''
    def __init__(self, expression, *, lineno=None):
        assert isinstance(expression, Expression)    # Sanity check on correctness.
        self.expression = expression
        self.lineno = lineno

    def __repr__(self):
        return f'PrintStatement({self.expression})'

class AssignmentStatement(Statement):
    '''
    location = expression ;
    '''
    def __init__(self, location, expression, *, lineno=None):
        assert isinstance(location, Location)  # <<<< NOT ARBITRARY EXPRESSION
        assert isinstance(expression, Expression)
        self.location = location
        self.expression = expression
        self.lineno = lineno

    def __repr__(self):
        return f'AssignmentStatement({self.location}, {self.expression})'


class ConstDefinition(Definition):
    '''
    const name = expression;      // Expression is required.
    const name int = expression;  // Allowed in the spec. 
    const pi int = 3.14159;       // Technically allowed in syntax of Wabbit (even though wrong)
    '''
    def __init__(self, name, dtype, expression, *, lineno=None):
        assert isinstance(name, str)
        assert isinstance(dtype, str) or dtype is None
        assert isinstance(expression, Expression)
        self.name = name
        self.dtype = dtype
        self.expression = expression
        self.lineno = lineno

    def __repr__(self):
        return f'ConstDefinition({self.name}, {self.dtype}, {self.expression})'

class VarDefinition(Definition):
    '''
    var name [type] [= expression];
    
    # Note: Could have an optional type
    var name int = 42;

    # Note: Could have optional value;
    var name int;

    # Note: Both type and value can't be missing.
    var name;         // NO!!!!!  

    var pi float = 3.14159;  // OK. Yes, type is definitely known!
    var pi = 3.14159;        // OK. Type inferred from the 3.14159
    var pi float;            // OK. Type explicitly stated.
    var pi;                  // ERROR. Can't determine the type
    '''
    def __init__(self, name, dtype=None, expression=None, *, lineno=None):
        assert isinstance(name, str) and len(name) > 0
        assert not (dtype is None and expression is None)
        self.name = name
        self.dtype = dtype
        self.expression = expression
        self.lineno = lineno

    def __repr__(self):
        return f'VarDefinition({self.name}, {self.dtype}, {self.expression})'

# Hint:  "if-statement"
#
#   if (test) { consequence } else { alternative }
#

class IfStatement(Statement):
    def __init__(self, test, consequence, alternative, *, lineno=None):
        assert isinstance(test, Expression)
        assert isinstance(consequence, list)   # list of statements
        assert isinstance(alternative, list)

        self.test = test
        self.consequence = consequence
        self.alternative = alternative
        self.lineno = lineno

    def __repr__(self):
        return f'IfStatement({self.test}, {self.consequence}, {self.alternative})'

class IfLetStatement(Statement):
    def __init__(self, pattern, value, consequence, alternative, *, lineno=None):
        assert isinstance(pattern, Pattern)
        assert isinstance(value, Expression)
        assert isinstance(consequence, list)   # list of statements
        assert isinstance(alternative, list)

        self.pattern = pattern
        self.value = value
        self.consequence = consequence
        self.alternative = alternative
        self.lineno = lineno

    def __repr__(self):
        return f'IfLetStatement({self.pattern}, {self.value}, {self.consequence}, {self.alternative})'

class WhileStatement(Statement):
    def __init__(self, test, body, *, lineno=None):
        assert isinstance(test, Expression)
        assert isinstance(body, list)
        self.test = test
        self.body = body
        self.lineno = lineno
        
    def __repr__(self):
        return f'WhileStatement({self.test}, {self.body})'

class WhileLetStatement(Statement):
    def __init__(self, pattern, value, body, *, lineno=None):
        assert isinstance(pattern, Pattern)
        assert isinstance(value, Expression)
        assert isinstance(body, list)
        self.pattern = pattern
        self.value = value
        self.body = body
        self.lineno = lineno
        
    def __repr__(self):
        return f'WhileLetStatement({self.pattern}, {self.value}, {self.body})'

class BreakStatement(Statement):
    def __init__(self, *, lineno=None):
        self.lineno = lineno

class ContinueStatement(Statement):
    def __init__(self, *, lineno=None):
        self.lineno = lineno

# Locations. A "location" is a place where you load and store values.
# Like a variable:
#
#     var x int;
#
#     x = 4;         // Stores 4 into x
#     print x;       // Loads x and prints it out.
#
# However, the concept of a "location" is a tricky one.  What about
# structure/class attributes?
#
#     p.x = 4;      
#     print p.x;
#     a[n] = 4;
#     a[n+23] = 4;
#     a[p.n + 23] = 4;
# 
#     2 + x     (x is Location, also an expression) 

class NamedLocation(Location):
    '''
    A simple name like "x"
    '''
    def __init__(self, name, *, lineno=None):
        assert isinstance(name, str)
        self.name = name
        self.lineno = lineno
        
    def __repr__(self):
        return f'NamedLocation({self.name})'

# Future expansion... other kinds of "locations"
class DottedLocation(Location):
    pass

# ----------------------------------------------------------------------
# Functions - Project 9

class FunctionDefinition(Definition):
    def __init__(self, name, parameters, return_type, body, *, lineno=None):
        self.name = name
        self.parameters = parameters
        self.return_type = return_type
        self.body = body
        self.lineno = lineno

    def __repr__(self):
        return f'FunctionDefinition({self.name}, {self.parameters}, {self.return_type}, {self.body})'

class Parameter(Definition):
    def __init__(self, name, dtype, *, lineno=None):
        self.name = name
        self.dtype = dtype
        self.lineno = lineno

    def __repr__(self):
        return f'Parameter({self.name}, {self.dtype})'

class FunctionApplication(Expression):
    def __init__(self, name, arguments, *, lineno=None):
        self.name = name
        self.arguments = arguments
        self.lineno = lineno

    def __repr__(self):
        return f'FunctionApplication({self.name}, {self.arguments})'

class ReturnStatement(Statement):
    def __init__(self, expression, *, lineno=None):
        self.expression = expression
        self.lineno = lineno

    def __repr__(self):
        return f'ReturnStatement({self.expression})'

# ----------------------------------------------------------------------
# Structs/Enums (Project 10)
#

# "struct name { fields }"
class StructDefinition(Definition):
    def __init__(self, name, fields, *, lineno=None):
        assert isinstance(name, str)
        assert isinstance(fields, list) and all(isinstance(f, StructField) for f in fields)
        self.name = name
        self.fields = fields
        self.lineno = lineno

    def __repr__(self):
        return f'StructDefinition({self.name}, {self.fields})'

# A single struct field:   "name type;"
class StructField(Node):
    def __init__(self, name, dtype, *, lineno=None):
        assert isinstance(name, str)
        assert isinstance(dtype, str)
        self.name = name
        self.dtype = dtype
        self.lineno = lineno

    def __repr__(self):
        return f'StructField({self.name}, {self.dtype})'

# A field location
class DotLocation(Location):
    def __init__(self, expression, name, *, lineno=None):
        assert isinstance(expression, Expression)
        assert isinstance(name, str)
        self.expression = expression
        self.name = name
        self.lineno= lineno


    def __repr__(self):
        return f'DotLocation({self.expression}, {self.name})'

# "enum name { choices }"
class EnumDefinition(Definition):
    def __init__(self, name, choices, *, lineno=None):
        assert isinstance(name, str)
        assert isinstance(choices, list) and all(isinstance(c, EnumChoice) for c in choices)
        self.name = name
        self.choices = choices
        self.lineno = lineno

    def __repr__(self):
        return f'EnumDefinition({self.name}, {self.choices})'

# A single choice:  "Name;"  or "Name(dtype);"
class EnumChoice(Node):
    def __init__(self, name, dtype, *, lineno=None):
        assert isinstance(name, str)
        assert dtype is None or isinstance(dtype, str)
        self.name = name
        self.dtype = dtype
        self.lineno = lineno

    def __repr__(self):
        return f'EnumChoice({self.name}, {self.dtype})'

# An enum value:  "EnumName::ChoiceName" or "EnumName::ChoiceName(expression)"
class EnumValue(Expression):
    def __init__(self, enum_name, choice_name, expression, *, lineno=None):
        assert isinstance(enum_name, str)
        assert isinstance(choice_name, str)
        assert expression is None or isinstance(expression, Expression)
        self.enum_name = enum_name
        self.choice_name = choice_name
        self.expression = expression
        self.lineno = lineno

    def __repr__(self):
        return f'EnumValue({self.enum_name}, {self.choice_name}, {self.expression})'

# "match expression { clauses }"
class Match(Expression):
    def __init__(self, expression, clauses, *, lineno=None):
        assert isinstance(expression, Expression)
        assert isinstance(clauses, list) and all(isinstance(c, MatchClause) for c in clauses)
        self.expression = expression
        self.clauses = clauses
        self.lineno = lineno

    def __repr__(self):
        return f'Match({self.expression}, {self.clauses})'

# A single match clause:   "ChoiceName => Expression"
#                       or "ChoiceName(VarName) => Expression"
class MatchClause(Node):
    def __init__(self, pattern, expression, *, lineno=None):
        assert isinstance(pattern, Pattern)
        assert isinstance(expression, Expression)
        self.pattern = pattern
        self.expression = expression
        self.lineno = lineno

    def __repr__(self):
        return f'MatchClause({self.pattern}, {self.expression})'

class Pattern:
    pass

class NamePattern(Pattern):
    def __init__(self, name, *, lineno=None):
        self.name = name
        self.lineno = lineno

    def __repr__(self):
        return f'NamePattern({self.name})'

class NameValuePattern(Pattern):
    def __init__(self, name, varname, *, lineno=None):
        self.name = name
        self.varname = varname
        self.lineno = lineno

    def __repr__(self):
        return f'NameValuePattern({self.name}, {self.varname})'

# ------ Model Visitor
#
# This is a more properly defined class to facilitate manipulation of the Model.
# One concern is the identification/elimination of errors.  This class is defined
# as an ABC (abstract base class) to force implementation of the required methods.
# This ensures that you're not forgetting something.

class ModelVisitor:
    @classmethod
    def __init_subclass__(cls):
        for name in cls.__dict__:
            if name.startswith('visit_') and name[6:] not in Node._registered:
                raise RuntimeError(f"No matching model node for {name}")

    # Top-level visit function. Dispatches to a method of the appropriate type
    def visit(self, node):
        method_name = f'visit_{type(node).__name__}'
        method = getattr(self, method_name, None)
        if method:
            return method(node)

    def visit_list(self, node):
        for item in node:
            self.visit(item)

# ------ Debugging function to convert a model into source code (for easier viewing)

def to_source(node):
    if isinstance(node, (Integer, Float, Char, Bool)):
        return repr(node.value)
    elif isinstance(node, BinOp):
        return f'{to_source(node.left)} {node.op} {to_source(node.right)}'
    elif isinstance(node, UnaryOp):
        return f'{node.op}{to_source(node.operand)}'
    elif isinstance(node, PrintStatement):
        return f'print {to_source(node.expression)};\n'
    elif isinstance(node, VarDefinition):
        dtype = node.dtype if node.dtype else ''
        expr = f'= {to_source(node.expression)}' if node.expression else ''
        return f'var {node.name} {dtype} {expr};\n'
    elif isinstance(node, ConstDefinition):
        dtype = node.dtype if node.dtype else ''
        expr = f'= {to_source(node.expression)}' if node.expression else ''
        return f'const {node.name} {dtype} {expr};\n'
    elif isinstance(node, AssignmentStatement):
        return f'{to_source(node.location)} = {to_source(node.expression)};\n'

    elif isinstance(node, LoadLocation):
        return f'{to_source(node.location)}'

    elif isinstance(node, NamedLocation):
        return node.name

    elif isinstance(node, IfStatement):
        return (f'if {to_source(node.test)}' + '{\n' + 
               to_source(node.consequence) + '} else {\n' + 
               to_source(node.alternative) + '}\n')

    elif isinstance(node, WhileStatement):
        return (
            f'while {to_source(node.test)}' + '{\n' +
            to_source(node.body) + '}\n')

    elif isinstance(node, BreakStatement):
        return "break;\n"

    elif isinstance(node, ContinueStatement):
        return "continue;\n"

    elif isinstance(node, list):
        return ''.join(to_source(item) for item in node)
    elif node is None:
        return str(node)
    else:
        raise RuntimeError(f"Can't convert {node} to source")



    
