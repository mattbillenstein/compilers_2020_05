# parse.py
#
# Wabbit parser.  The parser needs to construct the data model or an
# abstract syntax tree from text input.  The grammar shown here represents
# WabbitScript--a subset of the full Wabbit language.  It's written as
# a EBNF.  You will need to expand the grammar to include later features.
#
# Reference: https://github.com/dabeaz/compilers_2020_05/wiki/WabbitScript
#
# The following conventions are used:
# 
#       ALLCAPS       --> A token
#       { symbols }   --> Zero or more repetitions of symbols
#       [ symbols ]   --> Zero or one occurences of symbols (optional)
#       s | t         --> Either s or t (a choice)
#
#
# statements : { statement }
#
# statement : print_statement
#           | assignment_statement
#           | variable_definition
#           | const_definition
#           | if_statement
#           | while_statement
#           | break_statement
#           | continue_statement
#           | expr
#
# print_statement : PRINT expr SEMI
#
# assignment_statement : location ASSIGN expr SEMI
#
# variable_definition : VAR NAME [ type ] ASSIGN expr SEMI
#                     | VAR NAME type [ ASSIGN expr ] SEMI
#
# const_definition : CONST NAME [ type ] ASSIGN expr SEMI
#
# if_statement : IF expr LBRACE statements RBRACE [ ELSE LBRACE statements RBRACE ]
#
# while_statement : WHILE expr LBRACE statements RBRACE
#
# break_statement : BREAK SEMI
#
# continue_statement : CONTINUE SEMI
#
# expr : expr PLUS expr        (+)
#      | expr MINUS expr       (-)
#      | expr TIMES expr       (*)
#      | expr DIVIDE expr      (/)
#      | expr LT expr          (<)
#      | expr LE expr          (<=)
#      | expr GT expr          (>)
#      | expr GE expr          (>=)
#      | expr EQ expr          (==)
#      | expr NE expr          (!=)
#      | expr LAND expr        (&&)
#      | expr LOR expr         (||)
#      | PLUS expr
#      | MINUS expr
#      | LNOT expr              (!)
#      | LPAREN expr RPAREN 
#      | location
#      | literal
#      | LBRACE statements RBRACE 
#       
# literal : INTEGER
#         | FLOAT
#         | CHAR
#         | TRUE
#         | FALSE
#         | LPAREN RPAREN   
# 
# location : NAME
#
# type      : NAME
#
# empty     :
# ======================================================================

# How to proceed:  
#
# At first glance, writing a parser might look daunting. The key is to
# take it in tiny pieces.  Focus on one specific part of the language.
# For example, the print statement.  Start with something really basic
# like printing literals:
#
#     print 1;
#     print 2.5;
#
# From there, expand it to handle expressions:
#
#     print 2 + 3 * -4;
#
# Then, expand it to include variable names
#
#     var x = 3;
#     print 2 + x;
#
# Keep on expanding to more and more features of the language.  A good
# trajectory is to follow the programs found in the top level
# example_models.py file.  That is, write a parser that can recognize the
# source code for each part and build the corresponding model.  You
# will find yourself filling in pieces here throughout the project.
# It's ok to work piecemeal.
#
# Usage of tools:
#
# If you are highly motivated and want to know how a parser works at a
# low-level, you can write a hand-written recursive descent parser.
# It is also fine to use high-level tools such as 
#
#    - SLY (https://github.com/dabeaz/sly), 
#    - PLY (https://github.com/dabeaz/ply),
#    - ANTLR (https://www.antlr.org).

from .model import *
from sly import Parser
from .tokenize import WabbitLexer, tokenize

class WabbitParser(Parser):
    # debugfile = 'parser.out'

    tokens = WabbitLexer.tokens

    # Lowest precedence to highest precedence (fix shift-reduce conflict errors).
    # Shift-reduce almost always caused by ambiguity in precedence. Example:
    #     2 + 3 * 4  -> '(2 + 3) * 4' or '2 + (3 * 4)'
    precedence = [
        # low-precedence
        ('left', LOR),
        ('left', LAND),
        ('left', LT, LE, GT, GE, NE, EQ),
        ('left', PLUS, MINUS),       # +, - are left associative. Same precedence.
        ('left', TIMES, DIVIDE),     # *, / are left associative. Same precedence (higher than +-)
        ('right', LNOT),             
        ('left', DOT),
        # high-precedence
        ]

    # This is one or more statements. SLY will automatically create a list for you.
    # p.statement is a list
    @_('{ statement }')    # 0 or more repetitions (GRAMMAR)
    def statements(self, p):
        return p.statement    # this is a list  (SLY internal)

    #      p[0]
    #        v
    @_('print_statement',
       'assignment_statement',
       'const_definition',
       'var_definition',
       'expr_as_statement',
       'if_statement',
       'if_let_statement',
       'while_statement',
       'while_let_statement',
       'break_statement',
       'continue_statement',
       )
    def statement(self, p):
        return p[0]

    # One simplification---call this "statement".
    #   p[0]  p[1]  p[2]    (alternative syntax)
    #    v     v    v
    @_('PRINT expr SEMI')
    def print_statement(self, p):
        # This is how you get line numbers
        # print("print statement at line:", p.lineno)   # Line number of left-most token
        return PrintStatement(p.expr, lineno=p.lineno)

    # This declaration says that "expr" all by itself is a statement
    @_('expr SEMI')
    def expr_as_statement(self, p):
        return p.expr        # Just return whatever the expression is

    # a = 4
    # AssignmentStatement(NamedLocation('a'), Integer(4))

    @_('location ASSIGN expr SEMI')
    def assignment_statement(self, p):
        return AssignmentStatement(p.location, p.expr, lineno=p.lineno)

    # Insight: LALR(1) parsing....
    # Inside:  symbol_stack = [ ]
    #     Shift(sym) :   symbol_stack.append(sym)
    #     Reduce()   :   symbol_stack[-nsym:] = [ newvalue ]    (multiple values)
    #                :   symbol_stack == [ complete_model ]  --> return value
    #
    # Tokenizing:::::   CONST           (Shift)
    #                   NAME            (Shift)
    #                   NAME(type)      (Shift)
    #                   ASSIGN          (Shift)
    #                   ...
    #                   SEMI            (Shift)
    #                   Reduce(const_definition)
    #
    @_('CONST NAME [ type ] ASSIGN expr SEMI')
    def const_definition(self, p):
        return ConstDefinition(p.NAME, p.type, p.expr, lineno=p.lineno)

    @_('VAR NAME [ type ] ASSIGN expr SEMI')
    def var_definition(self, p):
        return VarDefinition(p.NAME, p.type, p.expr, lineno=p.lineno)

    @_('VAR NAME type SEMI')
    def var_definition(self, p):
        return VarDefinition(p.NAME, p.type, None, lineno=p.lineno)

    @_('IF expr LBRACE statements RBRACE')
    def if_statement(self, p):
        return IfStatement(p.expr, p.statements, [], lineno=p.lineno)

    @_('IF expr LBRACE statements RBRACE ELSE LBRACE statements RBRACE')
    def if_statement(self, p):
        return IfStatement(p.expr, p.statements0, p.statements1, lineno=p.lineno)

    @_('IF LET pattern ASSIGN expr LBRACE statements RBRACE [ ELSE LBRACE statements RBRACE ]')
    def if_let_statement(self, p):
        return IfLetStatement(p.pattern, p.expr, p.statements0, p.statements1 if p.statements1 else [], lineno=p.lineno)

    @_('WHILE expr LBRACE statements RBRACE')
    def while_statement(self, p):
        return WhileStatement(p.expr, p.statements, lineno=p.lineno)

    @_('WHILE LET pattern ASSIGN expr LBRACE statements RBRACE')
    def while_let_statement(self, p):
        return WhileLetStatement(p.pattern, p.expr, p.statements, lineno=p.lineno)

    @_('BREAK SEMI')
    def break_statement(self, p):
        return BreakStatement(lineno=p.lineno)

    @_('CONTINUE SEMI')
    def continue_statement(self, p):
        return ContinueStatement(lineno=p.lineno)

    @_('INTEGER')
    def expr(self, p):
        return Integer(int(p.INTEGER), lineno=p.lineno)

    @_('FLOAT')
    def expr(self, p):
        return Float(float(p.FLOAT), lineno=p.lineno)

    @_('CHAR')
    def expr(self, p):
        return Char(p.CHAR, lineno=p.lineno)

    @_('TRUE')
    def expr(self, p):
        return Bool(True, lineno=p.lineno)

    @_('FALSE')
    def expr(self, p):
        return Bool(False, lineno=p.lineno)

    @_('LPAREN RPAREN')
    def expr(self, p):
        return Unit(lineno=p.lineno)

    # All binary operators.  You can group them all into one rule!
    @_('expr PLUS expr',    # or
       'expr MINUS expr',   # or
       'expr TIMES expr',   # or
       'expr DIVIDE expr',
       'expr LT expr',
       'expr LE expr',
       'expr GT expr',
       'expr GE expr',
       'expr EQ expr',
       'expr NE expr',
       'expr LAND expr',     # Logical and (&&)
       'expr LOR expr',      # Logical or (||)
       )
    def expr(self, p):
        # p[1] here refers to the token value of whatever is in position 1
        # (PLUS, MINUS, TIMES, DIVIDE, etc.)
        return BinOp(p[1], p.expr0, p.expr1, lineno=p.lineno)

    @_('MINUS expr',
       'PLUS expr',
       'LNOT expr')
    def expr(self, p):
        return UnaryOp(p[0], p.expr, lineno=p.lineno)

    # Expression grouping ( .. )
    @_('LPAREN expr RPAREN')
    def expr(self, p):
        return p.expr

    # A location can be an expression
    #  2 + a   -> BinOp('+', Integer(2), LoadLocation(NamedLocation('a')))

    # Compound Expression { expr1; expr2 }
    @_('LBRACE statements RBRACE')
    def expr(self, p):
        return Compound(p.statements, lineno=p.lineno)

    @_('location')
    def expr(self, p):
        return LoadLocation(p.location, lineno=p.location.lineno)

    @_('NAME')
    def location(self, p):
        return NamedLocation(p.NAME, lineno=p.lineno)

    @_('NAME')
    def type(self, p):
        return p.NAME

    # Parser extensions for functions.
    # One technicality--parameters and arguments could be empty (zero-argument function)

    @_('function_definition',
       'return_statement')
    def statement(self, p):
        return p[0]

    @_('FUNC NAME LPAREN [ parameters ] RPAREN [ type ] LBRACE statements RBRACE')
    def function_definition(self, p):
        parms = p.parameters if p.parameters else [ ]
        rettype = p.type if p.type else "unit"
        return FunctionDefinition(p.NAME, parms, rettype, p.statements, lineno=p.lineno)

    # This is one or more parameters separated by comma
    # The second "parameter" is already a list (via SLY).
    @_('parameter { COMMA parameter }')    # { thing }  --> 0 or more repetitions of thing
    def parameters(self, p):
        return [ p.parameter0 ] + p.parameter1
                 # single param   # list of parameters
    @_('NAME type')
    def parameter(self, p):
        return Parameter(p.NAME, p.type, lineno=p.lineno)

    @_('NAME LPAREN [ exprlist ] RPAREN')
    def expr(self, p):
        exprs = p.exprlist if p.exprlist else [ ]
        return FunctionApplication(p.NAME, exprs, lineno=p.lineno)

    @_('expr { COMMA expr }')
    def exprlist(self, p):
        return [p.expr0] + p.expr1

    @_('RETURN expr SEMI')
    def return_statement(self, p):
        return ReturnStatement(p.expr, lineno=p.lineno)

    # Parser extensions for Wabbit type
    @_('struct_definition',
       'enum_definition')
    def statement(self, p):
        return p[0]

    @_('STRUCT NAME LBRACE { structfield } RBRACE')
    def struct_definition(self, p):
        return StructDefinition(p.NAME, p.structfield, lineno=p.lineno)

    @_('NAME type SEMI')
    def structfield(self, p):
        return StructField(p.NAME, p.type, lineno=p.lineno)

    @_('ENUM NAME LBRACE { enumchoice } RBRACE')
    def enum_definition(self, p):
        return EnumDefinition(p.NAME, p.enumchoice, lineno=p.lineno)

    @_('NAME [ LPAREN type RPAREN ] SEMI')
    def enumchoice(self, p):
        return EnumChoice(p.NAME, p.type, lineno=p.lineno)

    @_('MATCH expr LBRACE { matchclause } RBRACE')
    def expr(self, p):
        return Match(p.expr, p.matchclause, lineno=p.lineno)
    
    @_('pattern ARROW expr SEMI')
    def matchclause(self, p):
        return MatchClause(p.pattern, p.expr, lineno=p.lineno)

    @_('NAME DCOLON NAME [ LPAREN expr RPAREN ]')
    def expr(self, p):
        return EnumValue(p.NAME0, p.NAME1, p.expr, lineno=p.lineno)

    @_('NAME')
    def pattern(self, p):
        return NamePattern(p.NAME, lineno=p.lineno)

    @_('NAME LPAREN NAME RPAREN')
    def pattern(self, p):
        return NameValuePattern(p.NAME0, p.NAME1, lineno=p.lineno)

    @_('expr DOT NAME')
    def location(self, p):
        return DotLocation(p.expr, p.NAME, lineno=p.lineno)
    
def parse_source(text):
    toks = tokenize(text)
    parser = WabbitParser()
    return parser.parse(toks)

# Example of a main program
def parse(filename):
    with open(filename) as file:
        text = file.read()

    model = parse_source(text)
    return model

if __name__ == '__main__':
    import sys
    if len(sys.argv) != 2:
        raise SystemExit('Usage: wabbit.parse filename')
    model = parse(sys.argv[1])
    print(model)


