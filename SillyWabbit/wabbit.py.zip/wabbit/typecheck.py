# typecheck.py
'''
Type Checking
=============
This file implements type checking. Wabbit uses what's known as
"nomimal typing."  That means that types are given unique
names such as "int", "float", "bool", etc. Two types are the same
if they have exactly the same name.  That's it.

In implementing the type checker, the best strategy might be to
not overthink the problem at hand. Basically, you have type names.
You can represent these names using Python strings and compare them
using string comparison. This gives you most of what you need.

In some cases, you might need to check combinations of types against a
large number of cases (such as when implementing the math operators).
For that, it helps to make lookup tables.  For example, you can use
Python dictionaries to build lookup tables that encode valid
combinations of binary operators.  For example:

_binops = {
    # ('lefttype', 'op', 'righttype') : 'resulttype'
    ('int', '+', 'int') : 'int',
    ('int', '-', 'int') : 'int',
    ...
}

The directory tests/Errors has Wabbit programs with various errors.
'''

from .model import *
from collections import ChainMap
from functools import singledispatch

# Built-in type names
_builtin_types = { 'int', 'float', 'char', 'bool', 'unit' }

# Error handling function

has_errors = False

def error(lineno, msg):
    global has_errors
    print(f'{lineno}: {msg}')
    has_errors = True

# Top level function that interprets an entire program. It creates the
# initial environment that's used for storing variables. Returns True
# or False if the program type-checks correctly.

def check_program(model):
    global has_errors

    has_errors = False
    # Make the environment (a dict)
    env = ChainMap()
    check(model, env)
    return not has_errors

def check_type(name, env):
    if name in _builtin_types:
        return True

    defn = env.get(name)
    return isinstance(defn, (StructDefinition, EnumDefinition))
    
@singledispatch
def check(node, env):
    raise RuntimeError(f'{node} not checked')

rule = check.register

@rule(list)
def check_list(node, env):
    ty = "unit"
    for item in node:
        ty = check(item, env)
    return ty if ty else "unit"

@rule(Integer)
def check_integer(node, env):
    return "int"

@rule(Float)
def check_float(node, env):
    return "float"

@rule(Char)
def check_char(node, env):
    return "char"

@rule(Bool)
def check_bool(node, env):
    return "bool"

@rule(Unit)
def check_unit(node, env):
    return "unit"

_binops = {
    # (lefttype, op, righttype) : resulttype

    # Integer operations
    ('int', '+', 'int') : 'int',
    ('int', '-', 'int') : 'int',
    ('int', '*', 'int') : 'int',
    ('int', '/', 'int') : 'int',

    ('int', '<', 'int') : 'bool',
    ('int', '<=', 'int') : 'bool',
    ('int', '>', 'int') : 'bool',
    ('int', '>=', 'int') : 'bool',
    ('int', '==', 'int') : 'bool',
    ('int', '!=', 'int') : 'bool',

    # Float operations
    ('float', '+', 'float') : 'float',
    ('float', '-', 'float') : 'float',
    ('float', '*', 'float') : 'float',
    ('float', '/', 'float') : 'float',

    ('float', '<', 'float') : 'bool',
    ('float', '<=', 'float') : 'bool',
    ('float', '>', 'float') : 'bool',
    ('float', '>=', 'float') : 'bool',
    ('float', '==', 'float') : 'bool',
    ('float', '!=', 'float') : 'bool',

    # Char operations.  There are none. But, they can be compared
    ('char', '<', 'char') : 'bool',
    ('char', '<=', 'char') : 'bool',
    ('char', '>', 'char') : 'bool',
    ('char', '>=', 'char') : 'bool',
    ('char', '==', 'char') : 'bool',
    ('char', '!=', 'char') : 'bool',

    # Bool operations.  Can be compared. Also, logical operators
    ('bool', '==', 'bool') : 'bool',
    ('bool', '!=', 'bool') : 'bool',
    ('bool', '&&', 'bool') : 'bool',
    ('bool', '||', 'bool') : 'bool',

    # Unit operations. Can be compared.
    ('unit', '==', 'unit') : 'bool',

}

@rule(BinOp)
def check_binop(node, env):
    # left + right
    left_type = check(node.left, env)
    right_type = check(node.right, env)

    # Table lookup
    result_type = _binops.get((left_type, node.op, right_type))
    if not result_type:
        error(node.lineno, f"Unsupported operation: {left_type} {node.op} {right_type}")

    return result_type

_unaryops = {
    # (operator, operand_type) : result_type
    ('+', 'int') : 'int',
    ('-', 'int') : 'int',

    ('+', 'float') : 'float',
    ('-', 'float') : 'float',

    ('!', 'bool') : 'bool',
}

@rule(UnaryOp)    
def check_unaryop(node, env):
    # -operand
    operand_type = check(node.operand, env)
    result_type = _unaryops.get((node.op, operand_type))
    if not result_type:
        error(node.lineno, f"Unsupported operation: {node.op}{operand_type}")
    return result_type

@rule(LoadLocation)
def check_load_location(node, env):
    get, _ = check(node.location, env)
    return get() if get else None

@rule(Compound)
def check_compound(node, env):
    return check(node.statements, env)

@rule(VarDefinition)
@rule(ConstDefinition)
def check_var_or_const_definition(node, env):
    '''
    var x int = 3.141; 
    '''
    # Thinking about errors
    if node.name in env:
        # Duplicate definition! 
        error(node.lineno, f"{node.name} already defined!")
        return
    # If there is a value (on the right), get it's type
    if node.expression:
        expr_type = check(node.expression, env)
    else:
        expr_type = None

    # What if there's no node.dtype?
    #  var x = (2 * 5+2);
    #
    if not node.dtype:
        var_type = expr_type         # Infer from expression
        node.dtype = var_type        # Fix the model????? 
    else:
        var_type = node.dtype

    if expr_type and var_type != expr_type:
        error(node.lineno, f'Type error in initialization. {var_type} != {expr_type}')

    env[node.name] = node

@rule(AssignmentStatement)
def check_assignment_statement(node, env):
    '''
    const x = 42;    // Type is int. 
    x = 2;           // Can't assign to const
    '''
    value_type = check(node.expression, env)
    _, set = check(node.location, env)
    if set:
        set(value_type)

@rule(IfStatement)
def check_if_statement(node, env):
    test_type = check(node.test, env)
    if test_type != 'bool':
        error(node.lineno, f'if test must be bool. Got {test_type}')
    # Check for errors in *both* branches.  Type checking doesn't run code.
    # It only looks at code. So, it has to look at code in both branches.
    check(node.consequence, env.new_child())   # Chainmap/Blockscope
    check(node.alternative, env.new_child())

@rule(IfLetStatement)
def check_iflet_statement(node, env):
    value_type = check(node.value, env)
    # Create a new environment
    env = env.new_child()
    # Check the pattern
    check(node.pattern, env)(value_type)
    check(node.consequence, env.new_child())
    check(node.alternative, env.new_child())

@rule(WhileStatement)    
def check_while_statement(node, env):
    test_type = check(node.test, env)
    if test_type != 'bool':
        error(node.lineno, f'while test must be bool. Got {test_type}')

    # Make sure there are no errors in the loop body
    newenv = env.new_child()
    newenv['while'] = True    # This is a marker used for checking break/continue
    check(node.body, newenv)

@rule(WhileLetStatement)
def check_whilelet_statement(node, env):
    value_type = check(node.value, env)
    # Create a new environment
    newenv = env.new_child()
    newenv['while'] = True
    # Check the pattern
    check(node.pattern, newenv)(value_type)
    check(node.body, newenv)

@rule(BreakStatement)
def check_break_statement(node, env):
    if not 'while' in env:
        error(node.lineno, 'break used outside of while loop')

@rule(ContinueStatement)
def check_continue_statement(node, env):
    if not 'while' in env:
        error(node.lineno, 'continue used outside of while loop')

@rule(PrintStatement)
def check_print_statement(node, env):
    # Make sure no errors in the printed expression
    ty = check(node.expression, env)
    if ty not in {'int', 'float', 'char', 'bool', 'unit', None}:
        error(node.lineno, f'Unsupported type {ty!r} with print')

@rule(FunctionDefinition)
def check_function_definition(node, env):
    # A function is like any other definition. It has a name. Because it has a name,
    # it goes into the environment
    env[node.name] = node
    
    # The body of the function needs to be checked in a new environment. This is
    # the local scope.  You can use ChainMap for this

    newenv = env.new_child()   # <<< ChainMap feature
    # Within this new environment.... you must define the function parameter names
    parmnames = set()
    for parm in node.parameters:
        if parm.name in parmnames:
            error(parm.lineno, f'Duplicate parameter name {parm.name}')
        parmnames.add(parm.name)
        newenv[parm.name] = parm

    if not check_type(node.return_type, env):
        error(node.lineno, f'{node.return_type} is not a valid type')

    newenv['return'] = node.return_type    # Inject return type in new environment

    # Must also check the body of the function
    check(node.body, newenv)

@rule(FunctionApplication)
def check_function_application(node, env):
    argtypes = [ check(arg, env) for arg in node.arguments ]
    # You look up the function definition
    func = env.get(node.name)
    if not func:
        error(node.lineno, f'{node.name} not defined!')
        return 

    if isinstance(func, StructDefinition):
        # Must verify number of types/arguments
        parameters = func.fields
        return_type = func.name
    elif isinstance(func, FunctionDefinition):
        parameters = func.parameters
        return_type = func.return_type
    else:
        error(node.lineno, f'{node.name} is not a function or structure!')
        return

    # Check types and function signature
    if len(argtypes) != len(parameters):
        error(node.lineno, f'Wrong # arguments. Expected {len(parameters)}.')

    # Check argument types against parameter types
    for n, (argtype, parm) in enumerate(zip(argtypes, parameters), start=1):
        if argtype != parm.dtype:
            error(node.lineno, f"Type error in argument {n}. Expected {parm.dtype}")

    # The return type of function application is the return type of the function
    return return_type

@rule(ReturnStatement)
def check_return_statement(node, env):
    # Make sure no errors in the returned value
    expr_type = check(node.expression, env)

    if 'return' not in env:
        error(node.lineno, "Return used outside of function")
        return

    # Make sure that the type of the return expression matches the type of the function!
    # Where does return_type come from?????
    return_type = env['return']
    if expr_type != return_type:
        error(node.lineno, "Type error in return")

@rule(StructDefinition)
def check_struct_definition(node, env):
    env[node.name] = node
    fieldnames = set()
    for field in node.fields:
        if field.name in fieldnames:
            error(field.lineno, f'Duplicate field {field.name}')
        fieldnames.add(field.name)
        if not check_type(field.dtype, env):
            error(field.lineno, f'{field.dtype} not a valid type')


@rule(EnumDefinition)
def check_enum_definition(node, env):
    env[node.name] = node
    choicenames = set()
    for choice in node.choices:
        if choice.name in choicenames:
            error(choice.lineno, f'Duplicate choice {choice.name}')
        choicenames.add(choice.name)
        if choice.dtype and not check_type(choice.dtype, env):
            error(choice.lineno, f'{choice.dtype} not a valid type')

@rule(EnumValue)
def check_enum_value(node, env):
    enum = env.get(node.enum_name)
    if not enum or not isinstance(enum, EnumDefinition):
        error(node.lineno, f'{node.enum_name} not an enum')
        return
    if node.expression:
        exprtype = check(node.expression, env)

    for choice in enum.choices:
        if choice.name == node.choice_name:
            break
    else:
        error(node.lineno, f'{node.choice_name} not a valid choice')
        return enum.name
    if node.expression and exprtype != choice.dtype:
        error(node.lineno, f'Value must be {choice.dtype}')

    return enum.name

@rule(Match)
def check_match(node, env):
    expr_type = check(node.expression, env)
    enum = env.get(expr_type)
    if not enum or not isinstance(enum, EnumDefinition):
        error(node.lineno, f'{expr_type} not an enum')
        return

    choices = { c.name: c for c in enum.choices }
    clause_type = None
    for clause in node.clauses:
        newenv = env.new_child()
        check(clause.pattern, newenv)(expr_type)
        c_type = check(clause.expression, newenv)
        if clause_type and clause_type != c_type:
            error(clause.lineno, f'Inconsistent types in match')
        else:
            clause_type = c_type
    return c_type

@rule(NamedLocation)
def check_named_location(node, env):
    if node.name not in env:
        error(node.lineno, f"{node.name} not defined!")
        return None, None

    # Get object associated with the name
    defn = env[node.name]

    # getter/setter functions
    def getter():
        return defn.dtype

    def setter(valtype):
        if isinstance(defn, ConstDefinition):
            error(node.lineno, "Can't assign to const")
        if defn.dtype != valtype:
            error(node.lineno, f"Type error in assignment. {defn.dtype} != {valtype}")
        return defn.dtype

    return getter, setter

@rule(DotLocation)
def check_dot_location(node, env):
    e_type = check(node.expression, env)
    struct_decl = env.get(e_type)
    if not isinstance(struct_decl, StructDefinition):
        error(node.lineno, f"Type {e_type} not a struct")
        return None, None
    for field in struct_decl.fields:
        if field.name == node.name:
            break
    else:
        error(node.lineno, f"No attribute {node.name}")
        return None, None

    def getter():
        return field.dtype

    def setter(valtype):
        if valtype != field.dtype:
            error(node.lineno, f'Type error {field.dtype} != {valtype}')
            return field.dtype
    return (getter, setter)

# ------ Pattern checking

@rule(NamePattern)
def check_name_pattern(pattern, env):
    def check(valuetype):
        # Look up the enum in the environment
        value_enum = env.get(valuetype)
        if not isinstance(value_enum, EnumDefinition):
            error(pattern.lineno, f'type {valuetype} is not an enum')
            return

        # See if the pattern name is in the enum
        for choice in value_enum.choices:
            if choice.name == pattern.name:
                break
        else:
            error(pattern.lineno, f'name {pattern.name} is not defined in enum {valuetype}')
            return
    
    return check

@rule(NameValuePattern)
def check_namevalue_pattern(pattern, env):
    def check(valuetype):
        # Look up the enum in the environment
        value_enum = env.get(valuetype)
        if not isinstance(value_enum, EnumDefinition):
            error(pattern.lineno, f'type {valuetype} is not an enum')
            return

        # See if the pattern name is in the enum
        for choice in value_enum.choices:
            if choice.name == pattern.name:
                break
        else:
            error(pattern.lineno, f'name {pattern.name} is not defined in enum {valuetype}')
            return
    
        # Bind a variable name to the enum dtype
        env[pattern.varname] = VarDefinition(pattern.varname, choice.dtype, None, lineno=pattern.lineno)
    return check

def main(filename):
    from .parse import parse
    model = parse(filename)
    check_program(model)

if __name__ == '__main__':
    import sys
    main(sys.argv[1])



        


        
