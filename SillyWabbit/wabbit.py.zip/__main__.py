import sys

if len(sys.argv) != 2:
    raise SystemExit(f"Usage: {sys.argv[0]} filename")

from wabbit.interp import main
main(sys.argv[1])
